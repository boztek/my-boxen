# VirtualBox Vagrant Module for Boxen

## Usage

```puppet
include vagrant
```

## Required Puppet Modules

None.
